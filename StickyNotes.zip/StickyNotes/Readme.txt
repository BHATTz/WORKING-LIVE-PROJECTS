Create a wonderful sticky notes keeper,

where all individual user will save their notes 

A pure HTML, CSS, JAVA SCRIPT website.